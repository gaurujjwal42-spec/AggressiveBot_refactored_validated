#!/usr/bin/env bash
set -euo pipefail
if ! command -v python >/dev/null 2>&1; then echo "python not found"; exit 1; fi
python -m venv .venv || true
source .venv/bin/activate
python -m pip install -U pip wheel setuptools
if [ -f pyproject.toml ]; then pip install -e ".[dev]" || pip install -e "."; 
elif [ -f requirements.txt ]; then pip install -r requirements.txt; fi
pytest -q || (echo "Tests failed"; exit 1)
# Update 'app' to real module or script
python -m aggbot "$@"
