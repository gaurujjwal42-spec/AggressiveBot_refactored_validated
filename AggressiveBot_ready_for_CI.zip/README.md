# Aggressive Bot (standardized)

## Quick start (Windows)
```bat
run.bat
```
or PowerShell:
```powershell
.un.ps1
```

## Build single-file EXE
```powershell
.uild_exe.ps1
```
Artifacts will appear in `dist/`.